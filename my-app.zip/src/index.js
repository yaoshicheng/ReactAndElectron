import React,{Component} from 'react';
import ReactDOM from 'react-dom';
import PropTypes from "prop-types";
import {
  HashRouter as Router,
  Route,
}from 'react-router-dom';
import { createStore , combineReducers} from 'redux'
import { Provider } from 'react-redux'
import './index.css';
import App from './App';
import CarInfoManage from './components/CarInfoManage';
import SimManage from './components/SimManage';
import * as serviceWorker from './serviceWorker';
import test1 from './models/test1'
import test2 from './models/test2'
const reducer = combineReducers({
  test1,test2
})
const store = createStore(reducer);

export default class Hello extends Component{
  getChildContext() {
    return { store:store};
  }
  render(){
    return (
      <Provider store={store} color="red">
        <Router>
          <div>
            <Route exact path="/" component={App} />
            <Route path="/CarInfoManage" component={CarInfoManage} />
            <Route path="/SimManage" component={SimManage} />
          </div>
        </Router>
      </Provider>
    )
  }
}
Hello.childContextTypes = {
  store: PropTypes.object
};

ReactDOM.render(<Hello />, document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
