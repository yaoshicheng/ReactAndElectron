import request from '../utils/request';


// 查询列表
export async function test() {
  const data = await request("http://www.baidu.com");
  console.log(data)
  return {
    data: 111
  };
}
export default {
  test,
};
