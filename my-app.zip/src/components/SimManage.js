import React,{Component} from 'react';
import '../App.css';
import editPic from '../assets/images/u152.png'
export default class About extends Component{
  constructor(props){
    super(props)
  }

  state={
    simInfo:[
      {simName:"自动驾驶",simNo:"qwexsfdssdg1111",simStatus:"正常",residualFlow:"1312",expireAt:"2019-11-30"},
      {simName:"自贩柜",simNo:"qwexsfdssdg1111",simStatus:"正常",residualFlow:"1312",expireAt:"2019-11-30"},
      {simName:"电器柜",simNo:"qwexsfdssdg1111",simStatus:"正常",residualFlow:"1312",expireAt:"2019-11-30"}
    ],
    editable:false,
    current:null,
  };

  naviToHome = () =>{
    this.props.history.push("/")
  };

  handleEditSim = (index) =>{
    this.setState({
      editable:true,
      current:index,
    })
  };
  handleSimNo = (value) =>{
    console.log(value)
    this.setState({
      editable:false,
      current:null,
    })
  }

  renderSim = () =>{
    const {simInfo,editable,current} = this.state;
    let elements = [];
    if(simInfo && simInfo.length>0){
      elements = simInfo.map((item,index)=>{
        const {simName,simNo,simStatus,residualFlow,expireAt} = item;
        return (
          <div className="sim-container">
            <h3 style={{marginLeft:"30px"}}>{simName}</h3>
            <div className="simInfoItem">
              <div className="car-info-name">SIM卡号</div>
              <div style={{flex:1,textAlign:"left"}}>
                {(editable&&current===index)?(<input value={simNo} onChange={this.handleSimNo} />):(simNo)}
              </div>
              <img onClick={()=>this.handleEditSim(index)} src={editPic} style={{ width:"26px",height:"20px",}} />
            </div>
            <div className="simInfoItem">
              <div className="car-info-name">SIM卡状态</div>
              <div>{simStatus}</div>
            </div>
            <div className="simInfoItem">
              <div className="car-info-name">剩余流量</div>
              <div>{residualFlow} M</div>
            </div>
            <div className="simInfoItem">
              <div className="car-info-name">有效期至</div>
              <div>{expireAt}</div>
            </div>
          </div>
        )
      })
    }
    return elements
  }

  render(){
    return (
      <div className="App">
        <div className="flex-row" style={{width:"90%",marginLeft:"5%",marginTop:"30px"}}>
          <div style={{fontSize:"30px",fontWeight:"bold"}}>SIM卡管理</div>
          <div className="navi-home-btn" onClick={this.naviToHome}>返回首页</div>
        </div>
        <div className="indexBody" style={{display:"flex",flexWrap: "wrap"}}>
          {this.renderSim()}
        </div>
      </div>
    )
  }
}